package com.crypto.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

/**
 * 
 * @author Uday_Bhavsar
 *
 */
@Controller
@RestController
public class FetchCryptoCurrency {

	@Autowired
	RestOperations operations;
	
	@RequestMapping(value="/bitcoin",method = RequestMethod.GET)
	public ModelAndView cryptoBitCoinCurrency(){
		
		String jsonFeed = operations.getForObject("http://localhost:8081/restservice/currencyhistory", String.class);

		return new ModelAndView("bitcoin","message",jsonFeed);
		
	}
	
	@RequestMapping(value="/ethereum",method = RequestMethod.GET)
	public ModelAndView cryptoEthereumCurrency() {
		
		String jsonFeed = operations.getForObject("http://localhost:8081/restservice/currencyhistory", String.class);

		return new ModelAndView("ethereum","message",jsonFeed);
		
	}
	
	@RequestMapping(value="/litecoin",method = RequestMethod.GET)
	public ModelAndView cryptoLiteCoinCurrency() {
		
		String jsonFeed = operations.getForObject("http://localhost:8081/restservice/currencyhistory", String.class);
		
		return new ModelAndView("litecoin","message",jsonFeed);
		
	}
	
	@Bean
	public RestOperations restTemplate() {
	    return new RestTemplate();
	}
}

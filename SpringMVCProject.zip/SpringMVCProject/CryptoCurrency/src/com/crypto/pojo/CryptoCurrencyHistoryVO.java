package com.crypto.pojo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CryptoCurrencyHistoryVO implements Serializable
{

private String currency;
private String date;
private List<Quote> quotes = null;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();
private final static long serialVersionUID = -1096118227762842324L;

/**
* No args constructor for use in serialization
* 
*/
public CryptoCurrencyHistoryVO() {
}

/**
* 
* @param quotes
* @param date
* @param currency
*/
public CryptoCurrencyHistoryVO(String currency, String date, List<Quote> quotes) {
super();
this.currency = currency;
this.date = date;
this.quotes = quotes;
}

public String getCurrency() {
return currency;
}

public void setCurrency(String currency) {
this.currency = currency;
}

public CryptoCurrencyHistoryVO withCurrency(String currency) {
this.currency = currency;
return this;
}

public String getDate() {
return date;
}

public void setDate(String date) {
this.date = date;
}

public CryptoCurrencyHistoryVO withDate(String date) {
this.date = date;
return this;
}

public List<Quote> getQuotes() {
return quotes;
}

public void setQuotes(List<Quote> quotes) {
this.quotes = quotes;
}

public CryptoCurrencyHistoryVO withQuotes(List<Quote> quotes) {
this.quotes = quotes;
return this;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

public CryptoCurrencyHistoryVO withAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
return this;
}

}

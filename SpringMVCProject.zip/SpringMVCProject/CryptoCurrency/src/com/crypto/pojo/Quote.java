package com.crypto.pojo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Quote implements Serializable
{

private String time;
private String price;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();
private final static long serialVersionUID = 3950625264126939495L;

/**
* No args constructor for use in serialization
* 
*/
public Quote() {
}

/**
* 
* @param time
* @param price
*/
public Quote(String time, String price) {
super();
this.time = time;
this.price = price;
}

public String getTime() {
return time;
}

public void setTime(String time) {
this.time = time;
}

public Quote withTime(String time) {
this.time = time;
return this;
}

public String getPrice() {
return price;
}

public void setPrice(String price) {
this.price = price;
}

public Quote withPrice(String price) {
this.price = price;
return this;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

public Quote withAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
return this;
}

}